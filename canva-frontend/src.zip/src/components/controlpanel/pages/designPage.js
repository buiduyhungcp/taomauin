import React from 'react';

const DesignPage = () => {
  return (
    <div>
      <h1>Control Panel - Thiết Kế</h1>
      <p>Đây là nội dung trang Thiết Kế của Control Panel.</p>
    </div>
  );
};

export default DesignPage;
