import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Control Panel - Trang Chủ</h1>
      <p>Đây là nội dung trang chủ của Control Panel.</p>
    </div>
  );
};

export default HomePage;
