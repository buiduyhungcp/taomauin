import React from 'react';

const OtherPage = () => {
  return (
    <div>
      <h1>Control Panel - Khác</h1>
      <p>Đây là nội dung trang Khác của Control Panel ss.</p>
    </div>
  );
};

export default OtherPage;
