import React from 'react';

const DesignPage = () => {
  return (
    <div>
      <h1>Canvas - Thiết Kế</h1>
      <p>Đây là nội dung trang Thiết Kế của Canvas.</p>
    </div>
  );
};

export default DesignPage;
