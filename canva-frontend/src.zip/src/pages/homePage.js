import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Canvas - Trang Chủ</h1>
      <p>Đây là nội dung trang chủ của Canvas.</p>
    </div>
  );
};

export default HomePage;
